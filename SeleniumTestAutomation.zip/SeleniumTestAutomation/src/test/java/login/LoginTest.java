package login;

import org.testng.annotations.Test;

import base.BaseTests;
import pages.FormPage;
import pages.LoginPage;

public class LoginTest extends BaseTests {

	 @Test(priority=1)
	    public void testSuccessfulLogin(){
		  driver.get("https://www.planradar.com/dr/1362538/ticket-types");
	        LoginPage loginPage = new LoginPage(driver);
	        loginPage.setUsername("marwaashour575@gmail.com");
	        loginPage.clickContinue();
	        loginPage.setPassword("QC123456789");
	        loginPage.clickLoginButton();
	       loginPage.asserttext();
	       FormPage FormPage = new FormPage(driver); 
	       FormPage.clickCreatebutton();
	       FormPage.setFormname("FormAutomation1");
	       FormPage.addshorttextfield();
	    }
}
