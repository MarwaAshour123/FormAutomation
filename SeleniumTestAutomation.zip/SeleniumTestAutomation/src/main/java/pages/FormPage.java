package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FormPage {
	 private WebDriver driver;
	 private WebDriverWait wait ;
	 private By createformbutton = By.cssSelector("div.ui-button-v2.ui-btn-create");
	 private By accessform = By.cssSelector(".form-text-placeholder.mb-0.w-full.line-clamp-3.border.text-2xl");
	 private By formnamefield =By.xpath("//input[@name='name']");
	 private By saveformname= By.cssSelector(".form-text-input:nth-child(1).ui-icon-v2:nth-child(1) > .svg-inline--fa");
	private By shorttext= By.linkText("Short Text");
	  
	    public FormPage(WebDriver driver){
	        this.driver = driver;
	        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	        
	    }
	 public void clickCreatebutton(){
	        wait.until(ExpectedConditions.elementToBeClickable(createformbutton)).click();
	        
	        
	    }
	 public void setFormname(String formname) {
		
		 wait.until(ExpectedConditions.elementToBeClickable(accessform)).click();
		 wait.until(ExpectedConditions.elementToBeClickable(formnamefield)).sendKeys(formname); 
		 wait.until(ExpectedConditions.elementToBeClickable(saveformname)).click();
		
	         
	 }
	    
	 public void addshorttextfield(){
	        wait.until(ExpectedConditions.elementToBeClickable(shorttext)).click();
	    }



}




