package pages;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {
	 private WebDriver driver;
	 private WebDriverWait wait ;
	    private By emailField = By.id("email");
	    private By ContinueButton=By.cssSelector("button.btn-block.btn-fetching-edge.btn.btn-success");
	    private By passwordField = By.id("password");
	    private By loginButton = By.cssSelector(".btn-block");
	    private By asserttext= By.cssSelector("h5.top-navbar-title");
	    public LoginPage(WebDriver driver){
	        this.driver = driver;
	        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	        
	    }

	    public void setUsername(String email){
	    	 wait.until(ExpectedConditions.visibilityOfElementLocated(emailField)).sendKeys(email);
	        
	    }
	    
	    public void clickContinue(){
	        wait.until(ExpectedConditions.elementToBeClickable(ContinueButton)).click();
	    }
	    public void setPassword(String password){
	        wait.until(ExpectedConditions.visibilityOfElementLocated(passwordField)).sendKeys(password);
	    }
	    
	    public void clickLoginButton(){
	        wait.until(ExpectedConditions.elementToBeClickable(loginButton)).click();
	       
	    }
	    public void asserttext() {
	    	
		       String expectedTitle="Forms and Lists";
		       assertEquals( wait.until(ExpectedConditions.visibilityOfElementLocated(asserttext)).getText(), expectedTitle);
	    }
	    
	    

}